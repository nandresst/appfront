﻿namespace pyback.Entidades
{
    public class Alumno
    {
        public int IdAlumno {get; set;}
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public bool Sexo { get; set; }
        public string Telefono { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Nacionalidad { get; set; }
        public string Foto { get; set; }

        public string Estado { get; set; }
    }
}
