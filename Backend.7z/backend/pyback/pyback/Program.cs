using pyback.Entidades;
using System.Data.SqlClient;
using System.Data;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using AspNetCore.Authentication.ApiKey;
using pyback.log;
//otras variables 
var builder = WebApplication.CreateBuilder(args);
var OrigenesPermitidos = builder.Configuration.GetValue<string>("OrigenesPermitidos");

// servicios -----------------------------------------------------------------


builder.Services.AddCors( opciones =>
{
    opciones.AddDefaultPolicy(configuracion =>
    {        
        configuracion.WithOrigins(OrigenesPermitidos).AllowAnyHeader().AllowAnyMethod();
    });

    opciones.AddPolicy("libre", configuracion =>
    {
        configuracion.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
    });
});

// Configurar la conexi�n a la base de datos
builder.Services.AddScoped<IDbConnection>(sp =>
    new SqlConnection(builder.Configuration.GetConnectionString("DefaultConnection")));
// -------------------------------------------
var app = builder.Build();

app.UseCors();
app.UseMiddleware<RequestAccesosMiddleware>();

app.MapGet("/", () => "Hello World!");

// Ejemplo de endpoint para obtener todos los alumnos
app.MapGet("/alumnos", async (IDbConnection connection) =>
{
    var query = "SELECT * FROM Alumno WHERE Estado=1";
    var alumnos = await connection.QueryAsync<Alumno>(query);
    return Results.Ok(alumnos);
});

// Ejemplo de endpoint para insertar un nuevo alumno
app.MapPost("/alumno", async (IDbConnection connection, Alumno alumno) =>
{
    var query = @"
        INSERT INTO Alumno (Nombres, Apellidos, Email, TipoDocumento, NroDocumento,
                              FechaNacimiento, Sexo, Telefono, FechaCreacion, Nacionalidad, Foto, Estado)
        VALUES (@Nombres, @Apellidos, @Email, @TipoDocumento, @NroDocumento,
                @FechaNacimiento, @Sexo, @Telefono, getdate(), @Nacionalidad, @Foto, 1)";

    await connection.ExecuteAsync(query, alumno);
    return Results.Ok();
});


app.MapPut("/alumno/{id}", async (IDbConnection connection, int id, Alumno alumno) =>
{
    var query = @"
    UPDATE Alumno
    SET Nombres = @Nombres,
        Apellidos = @Apellidos,
        Email = @Email,
        TipoDocumento = @TipoDocumento,
        NroDocumento = @NroDocumento,
        FechaNacimiento = @FechaNacimiento,
        Sexo = @Sexo,
        Telefono = @Telefono,
        Nacionalidad = @Nacionalidad,
        Foto = @Foto,
        Estado = @Estado
    WHERE IdAlumno = @Id";

    var parameters = new
    {
        Id = id,
        alumno.Nombres,
        alumno.Apellidos,
        alumno.Email,
        alumno.TipoDocumento,
        alumno.NroDocumento,
        alumno.FechaNacimiento,
        alumno.Sexo,
        alumno.Telefono,
        alumno.Nacionalidad,
        alumno.Foto,
        alumno.Estado
    };

    var rowsAffected = await connection.ExecuteAsync(query, parameters);

    if (rowsAffected > 0)
    {
        return Results.Ok();
    }
    else
    {
        return Results.NotFound();
    }
});



app.MapGet("/alumno/{id}", async (int id, IDbConnection connection) =>
{
    var query = "SELECT * FROM Alumno WHERE IdAlumno = @Id";
    var alumno = await connection.QuerySingleOrDefaultAsync<Alumno>(query, new { Id = id });

    if (alumno is null)
        return Results.NotFound();

    return Results.Ok(alumno);
});

app.Run();
