﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace pyback.log 
{  
    public class RequestAccesosMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestAccesosMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Obtener información de la solicitud
            var request = context.Request;
            var method = request.Method;
            var path = request.Path;
            var queryString = request.QueryString;

            // Guardar la información en un archivo de texto
            var logMessage = $"[{DateTime.Now}] {method} {path}{queryString}";
            await File.AppendAllTextAsync("requests.log", logMessage + Environment.NewLine);

            // Llamar al siguiente middleware
            await _next(context);
        }
    }
}
